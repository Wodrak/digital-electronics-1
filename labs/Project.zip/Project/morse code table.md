## Transfer table for morse code

case word is

